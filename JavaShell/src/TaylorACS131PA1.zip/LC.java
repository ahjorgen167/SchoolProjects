import java.util.concurrent.BlockingQueue;


public class LC extends Filter{
    public LC(
    BlockingQueue<Object> in, BlockingQueue<Object> out) {super(in, out);
    this.in = in;
    this.out = out;
    }
    @Override
    public void run(){
    	
    	try {
			int temp = getSize();
    		out.clear();
			out.put(temp);
		} catch (InterruptedException e) {}
    }
    public synchronized int getSize(){
		while(!in.isEmpty())
    		try {
    			wait();
			} catch (InterruptedException e) {}
		int temp = out.size();
		notify();
		return temp;
    }
    public Object transform(Object o){
    	return o;
    }
}
