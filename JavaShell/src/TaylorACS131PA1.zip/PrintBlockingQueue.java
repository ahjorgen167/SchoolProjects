import java.util.concurrent.BlockingQueue;

public class PrintBlockingQueue extends Filter {
    public PrintBlockingQueue(    
    BlockingQueue<Object> in,
    BlockingQueue<Object> out) {super(in, out);} 
    @Override
    public void run(){
        Object o = "";
//        if(in.isEmpty()){
//        	in.notify();
//        }

        while(!out.isEmpty()){
        try {
            o = this.out.take();
            o = transform(o);
        } catch (InterruptedException ex) {}}
//        while(in.isEmpty() != true && out.isEmpty() == true){
//        try {
//            o = this.in.take();
//            o = transform(o);
//        } catch (InterruptedException ex) {}}

    }
    public Object transform(Object o){
        System.out.println(o);
        return o;
    }    
    
}