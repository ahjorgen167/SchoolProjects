import java.util.List;
import java.util.concurrent.BlockingQueue;


public class SwitchStack extends Filter{
	    public SwitchStack(
	        BlockingQueue<Object> in, BlockingQueue<Object> out){super(in, out);
	        this.in = in;
	        this.out = out;
	    }
//	    @Override
//	    public void run(){
//	        while(!this.done)
//	    	try{
//	    	Object o = this.in.take();
//	    	int j = 0;
//	    	for(int i = 0; i < searchQueries.size(); i++){
//	    		if(!o.toString().contains(searchQueries.get(i)))
//	    			j++;
//	    	}
//	    	if(j!=searchQueries.size())
//				this.out.put(o);
//	    	}catch(Exception e){}
//	    }
	    @Override
	    public Object transform(Object o){
	    	//Working with inheritance!
	    	return o;
	    }
}
