import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.BlockingQueue;

public class OutputRedirect extends Filter{
    String title;
    List<String> historyList;
    public OutputRedirect(
    BlockingQueue<Object> in, BlockingQueue<Object> out, String title, List<String> historyList) {super(in, out);
    this.title = title;
    this.historyList = historyList;
    this.in = in;
    this.out = out;
    }
    @Override
    public void run(){
    	BufferedWriter writer = null;
        Object p;
        File actualFile = new File(historyListTransform(), title);
        while(!out.isEmpty()){
        try {            
        	writer = new BufferedWriter(new FileWriter(actualFile));
        	while(!out.isEmpty()){
            	p = out.take();
            	writer.write(p.toString());
	            writer.append(System.lineSeparator());
            }

			writer.close();
        } catch (IOException e) {
        } catch (InterruptedException ex) {}
        }
        
}    
    @Override
public Object transform(Object o){
        return o;
    }
    private String historyListTransform(){
		String historyOutput = historyList.get(0);
    	for (int i = 1; i < historyList.size(); i++) {
				historyOutput += "\\\\";
			historyOutput += historyList.get(i);
		}
		return historyOutput;
    }
}