import java.util.List;
import java.util.concurrent.BlockingQueue;


public class History extends Filter{
	public List<String> historyList;
	public History(BlockingQueue<Object> in, BlockingQueue<Object> out, List<String> historyList){super(in, out);
        this.historyList = historyList;
        this.in = in;
        this.out = out;
    }
	public void run(){
        for (int i = 0; i < historyList.size() - 1; i++)
			try {
				in.put(historyList.get(i));
			} catch (InterruptedException e) {}
	}
    public Object transform(Object o){
    	return o;
    }
}
